#!/system/bin/sh
# 开机后常驻：server.sh 退出就 5 秒后重启
D=/sdcard/Download/DSH-Go/rootbridge
i=0
while [ $i -lt 30 ]; do
  [ -d /sdcard/Download ] && break
  i=$((i+1)); sleep 2
done
while :; do
  sh "$D/server.sh" >> "$D/boot.log" 2>&1
  sleep 5
done
