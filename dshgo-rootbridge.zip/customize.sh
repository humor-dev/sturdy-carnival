#!/system/bin/sh
# 安装完成后立刻尝试启动一次（不必等到重启）
D=/sdcard/Download/DSH-Go/rootbridge
[ -f "$D/server.sh" ] && nohup sh "$D/server.sh" >> "$D/boot.log" 2>&1 &
true
