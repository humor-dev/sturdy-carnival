#!/system/bin/sh
D=/sdcard/Download/DSH-Go/rootbridge
[ -f "$D/pid" ] && kill "$(cat "$D/pid")" 2>/dev/null
exit 0
